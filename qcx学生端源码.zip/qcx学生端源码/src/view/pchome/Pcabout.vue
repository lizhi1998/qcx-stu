<template>
<div class="pcscore-card">
    <h3><i class="el-icon-s-flag" ></i> 关于我们</h3>
     <p>这个组织很神秘，暂时没有留下任何东西</p>
</div>
    
</template>

<script>


export default {
     components: {

  },
//    data() {
//     return {
// 		 info: {
//           id:localStorage.getItem('login_account'),
//           name:'',
//           academic:'',
//           major:'',
//           class:'',
//           dorm:'',	
// 		  monitor:'',
// 		  dormHeader:'' ,
// 		  free:'',
// 		  score:''
// 		},
// 	};
//   },
//   mounted() {
// 		this.getUserInfo()
		
//       },
// 		methods:{
// 			getUserInfo:function(){
// 				let get = getStu.getStuInfo(); 
// 				get.then(res =>{
// 					if (res.data !== undefined) {
// 					this.info.id = res.data.stuId
// 					this.info.name = res.data.stuName
// 					this.info.academic = res.data.stuAcademic
// 					this.info.major = res.data.stuMajor
// 					this.info.class = res.data.stuClass
// 					this.info.dorm = res.data.stuDorm
// 					// this.info.score = res.data.stuScore
// 					if(res.data.monitor == 1){ this.info.monitor = '任职中'}
// 					else {this.info.monitor = '否' }
// 					if(res.data.dormHeader == 1){ this.info.dormHeader = '任职中'}
// 					else {this.info.dormHeader = '否' }
// 					//  if(res.data.free == 1){ this.info.free = '已转出'}
// 					// else {this.info.free = '未转' }
// 					}
// 				})
			
// 			},
// 		}
    
}
</script>

<style >
.pcscore-card{
    margin-left: 15%;
    margin-top: 20px;
    margin-right: 15%;
}

</style>