<template>
  <transition name="van-fade">
    <router-view/>
  </transition>
</template>
<script>
export default {
  data() {
    return {};
  }
};
</script>
<style>
</style>