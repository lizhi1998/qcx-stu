<template>
    <el-footer class="dibu">
         <el-divider ></el-divider>
      <!-- <a :href="'https://www.fjut.edu.cn'" target="_blank">福建工程学院首页</a> | <a :href="'http://www.yiban.cn/school/index?school_id=549'" target="_blank">苍霞易班</a> | <a :href="'https://dh.fjut.edu.cn'" target="_blank">校内导航</a> | <a :href="'https://nids.fjut.edu.cn/authserver/login?service=http://i.fjut.edu.cn/index.portal'" target="_blank">
      校园信息门户</a> | <a :href="'https://jwxt.fjut.edu.cn/jwglxt/xtgl/login_slogin.html'" target="_blank">教务管理系统</a> | <a :href="'https://mail.fjut.edu.cn'" target="_blank">教师邮件系统</a> | <a :href="'https://jwc.fjut.edu.cn/2186/list.htm'" target="_blank">学校年历</a> -->
      <p >
    Copyright ©2018-2019 By 苍小易网络文化工作室 福建省福州市大学新区学府南路33号 350118
      </p>
</el-footer>

</template>
<script>

</script>
<style>
.dibu{
    position: relative;
    white-space:nowrap;
    font-size: 14px;
    text-align: center;
    background-color: white;
    margin-top: 50px;
    min-width: 850px;
    width: 100%;
    color: rgba(0, 0, 0, 0.45) !important;
}



</style>
